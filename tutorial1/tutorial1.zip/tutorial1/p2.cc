#include<iostream>
#include<string>

using namespace std;

int main(){
	int first, second;
	cout << "Please enter two integers: ";
	cin >> first >> second;
	cout << "The product of " << first << " and " << second << " is " << first * second << endl;
	return 0;
}
