#include<iostream>
#include<string>

using namespace std;

int main(){
	string username;
	cout << "Hi! What is your name? ";
	cin >> username;
	cout << "Hello " << username << "!" << endl;
	return 0;
}
